﻿namespace CapturaTela
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox_fotoUser = new System.Windows.Forms.PictureBox();
            this.label_fotoUser = new System.Windows.Forms.Label();
            this.button_captura = new System.Windows.Forms.Button();
            this.textBox_Usuario = new System.Windows.Forms.TextBox();
            this.label_user = new System.Windows.Forms.Label();
            this.label_link = new System.Windows.Forms.Label();
            this.txt_url = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_fotoUser)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pictureBox_fotoUser);
            this.groupBox1.Controls.Add(this.label_fotoUser);
            this.groupBox1.Controls.Add(this.button_captura);
            this.groupBox1.Controls.Add(this.textBox_Usuario);
            this.groupBox1.Controls.Add(this.label_user);
            this.groupBox1.Controls.Add(this.label_link);
            this.groupBox1.Controls.Add(this.txt_url);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(765, 415);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Captura Dados";
            // 
            // pictureBox_fotoUser
            // 
            this.pictureBox_fotoUser.Location = new System.Drawing.Point(137, 136);
            this.pictureBox_fotoUser.Name = "pictureBox_fotoUser";
            this.pictureBox_fotoUser.Size = new System.Drawing.Size(408, 253);
            this.pictureBox_fotoUser.TabIndex = 6;
            this.pictureBox_fotoUser.TabStop = false;
            // 
            // label_fotoUser
            // 
            this.label_fotoUser.AutoSize = true;
            this.label_fotoUser.Location = new System.Drawing.Point(33, 136);
            this.label_fotoUser.Name = "label_fotoUser";
            this.label_fotoUser.Size = new System.Drawing.Size(68, 13);
            this.label_fotoUser.TabIndex = 5;
            this.label_fotoUser.Text = "Foto usuario:";
            // 
            // button_captura
            // 
            this.button_captura.Location = new System.Drawing.Point(630, 366);
            this.button_captura.Name = "button_captura";
            this.button_captura.Size = new System.Drawing.Size(75, 23);
            this.button_captura.TabIndex = 4;
            this.button_captura.Text = "Capturar";
            this.button_captura.UseVisualStyleBackColor = true;
            this.button_captura.Click += new System.EventHandler(this.button_captura_Click);
            // 
            // textBox_Usuario
            // 
            this.textBox_Usuario.Location = new System.Drawing.Point(96, 80);
            this.textBox_Usuario.Name = "textBox_Usuario";
            this.textBox_Usuario.Size = new System.Drawing.Size(654, 20);
            this.textBox_Usuario.TabIndex = 3;
            // 
            // label_user
            // 
            this.label_user.AutoSize = true;
            this.label_user.Location = new System.Drawing.Point(33, 87);
            this.label_user.Name = "label_user";
            this.label_user.Size = new System.Drawing.Size(46, 13);
            this.label_user.TabIndex = 2;
            this.label_user.Text = "Usuario:";
            // 
            // label_link
            // 
            this.label_link.AutoSize = true;
            this.label_link.Location = new System.Drawing.Point(38, 38);
            this.label_link.Name = "label_link";
            this.label_link.Size = new System.Drawing.Size(30, 13);
            this.label_link.TabIndex = 1;
            this.label_link.Text = "Link:";
            // 
            // txt_url
            // 
            this.txt_url.Location = new System.Drawing.Point(96, 35);
            this.txt_url.Name = "txt_url";
            this.txt_url.Size = new System.Drawing.Size(654, 20);
            this.txt_url.TabIndex = 0;
            this.txt_url.TextChanged += new System.EventHandler(this.url_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 442);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_fotoUser)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_url;
        private System.Windows.Forms.Label label_link;
        private System.Windows.Forms.Button button_captura;
        private System.Windows.Forms.TextBox textBox_Usuario;
        private System.Windows.Forms.Label label_user;
        private System.Windows.Forms.PictureBox pictureBox_fotoUser;
        private System.Windows.Forms.Label label_fotoUser;
    }
}

