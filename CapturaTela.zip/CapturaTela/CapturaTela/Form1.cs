﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapturaTela
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            //Inicializa o formulário
            InitializeComponent();
        }

        //Navegador web
        WebBrowser navegador = new WebBrowser();

        private void Form1_Load(object sender, EventArgs e)
        {
            //Não mostra erros de script caso tenha
            navegador.ScriptErrorsSuppressed = true;
            //Transforma a página web em um evento para ser carregada ao clicarmos no botão de captura
            navegador.DocumentCompleted += new WebBrowserDocumentCompletedEventHandler(this.dados_Carregados);
        }

        private void dados_Carregados(object sender, EventArgs e)
        {
            try
            {
                //Captura o nome do usuário através do ID
                textBox_Usuario.Text = navegador.Document.GetElementById("fb-timeline-cover-name").InnerText;

                //Captura a imagem do usuário através da tag name img
                foreach (HtmlElement etiqueta in navegador.Document.GetElementsByTagName("img"))
                {
                    //Se o 'alt:' da imegem conter o nome do usuário, captura a imagem
                    if (etiqueta.GetAttribute("alt").Contains("Foto do perfil"))
                    {
                        //o campo da imagem recebe a imagem que está no atributo src
                        pictureBox_fotoUser.ImageLocation = etiqueta.GetAttribute("src");
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void url_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_captura_Click(object sender, EventArgs e)
        {
            navegador.Navigate(txt_url.Text);
        }


    }
}